name = "hicprediction"
from . import createBaseFile
from . import createTrainingSet
from . import training
from . import predict
from .configurations import *
